
// Apartado 1

//document.write("hola");
//document.write("<br>")
//document.getElementsByTagName("h1").innerHTML="hola";
//document.getElementsByTagName("h1").style.backgroundColor = 'red';
//let titulo1=document.getElementsByTagName("h1");
//document.write(titulo1);
//titulo1.innerHTML = "id='titulo1' Ex DOM y Eventos";
//document.write(titulo1);
//h1.document.style.background = 'red';
//h1.style.background = 'red';

//document.write("hola<br>")

//let h2=document.getElementsByTagName("h2");
//document.write(h2);

// Apartado 2

//let img = document.getElementById("imagenes");
//img.style.backgroundImage = 'url(../img/descarga.jpg)';

// Apartado 3


// Apartado 4

let texto = document.getElementById("texto");
texto.innerHTML = "12";




window.onload = function() {
    // Apartado 1

//document.getElementsByTagName("h1").innerHTML="hola";
//document.getElementsByTagName("h1").style.backgroundColor = 'red';
document.getElementsByTagName("h1").document.style.background="red";

//h1.document.style.background = 'red';
//h1.style.background = 'red';

document.write("hola<br>")

let h2=document.getElementsByTagName("h2");
document.write(h2);
}